﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Library.Models
{
    public class Rent
    {
        public int RentId { get; set; }
        public int PersonId { get; set; }
        public int BookId { get; set; }
        public int WriterId { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }

        public List<Person> people { get; set; }
    }
}
