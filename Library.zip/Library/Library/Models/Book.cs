﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Library.Models
{
    public class Book
    {
        //public Book()
        //{
        //    this.writers = new HashSet<Writer>();
        //}
        
        [Key]
        public int BookId { get; set; }
        [Required]
        public string Name { get; set; }

        public Person person { get; set; }
        public virtual ICollection<Writer> writers { get; set; }
    }
}
