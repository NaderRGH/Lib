﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Library.Models
{
    public class Writer
    {
        //public Writer()
        //{
        //    this.books = new HashSet<Book>();
        //}
        [Key]
        public int WriterId { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Family { get; set; }

        public virtual ICollection<Book> books { get; set; }
    }
}
